// apiConfig.js

const API_BASE_URL = "https://localhost:44313/api"; // Replace with your actual base URL

export default API_BASE_URL;
